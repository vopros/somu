Hi!

Execute this in console before running Sword:
`gem install haml coffee-script`

You install Sword like this:
`gem install sword`

Then, you go to this project’s folder:
`cd ~/desktop/easy` e.g.

And run it:
`sword`

Your project is avaliable at http://localhost:1111
Examine sources to understand how it works.
